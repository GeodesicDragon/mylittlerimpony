﻿// My Little RimPony - A RimWorld Mod
// Created by GeodesicDragon
// All aspects of MLP (except for Nurse Haywick) are property of Hasbro.
// Huge thanks to users of the official RimWorld Discord server for helping me with code.
// And also for being so damn patient with me while my slow brain figured it all out.
// I am always happy to accept updates to this code, especially if you have a better way of doing something I've done.
// Contact me via my Discord server and we'll talk! (Invite Code: BGKnpza)

using RimWorld;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using Verse;

namespace MyLittleRimPony
{

    // GAME STARTUP

    [StaticConstructorOnStartup]
    public static class MLRP_Startup
    {
        static MLRP_Startup()
        {
            var MLRP_Version = Assembly.GetExecutingAssembly().GetName().Version.ToString(3);
            Log.Message("MLRP_WelcomeMessage".Translate(MLRP_Version));

            if (ModsConfig.IsActive("geodesicdragon.rimpony.medieval"))
            {
                Log.Message("MLRP_MedievalOverhaul".Translate());
            }
        }
    }

    // ANTI BRONY PLUSHIE ALERT

    public class Alert_AntiBronyHasPlushie : Alert_Thought
    {
        protected override ThoughtDef Thought => DefDatabase<ThoughtDef>.GetNamed("MLRP_PonyPlushEquippedAntiBrony");

        public Alert_AntiBronyHasPlushie()
        {
            this.defaultLabel = "MLRP_AntiBronyHasPlushieAlert".Translate();
            this.explanationKey = "MLRP_AntiBronyHasPlushieExplanation";
        }
    }

    // ANTI BRONY HARMONY CHIP ALERT

    public class Alert_AntiBronyHasHarmonyChip : Alert_Thought
    {
        private bool royaltyActive;

        protected override ThoughtDef Thought
        {
            get
            {
                if (!royaltyActive)
                    return null;

                return DefDatabase<ThoughtDef>.GetNamed("MLRP_HarmonyChipInstalledAntiBrony", errorOnFail: false);
            }
        }

        public Alert_AntiBronyHasHarmonyChip()
        {
            royaltyActive = ModsConfig.IsActive("Ludeon.RimWorld.Royalty");

            if (royaltyActive)
            {
                this.defaultLabel = "MLRP_AntiBronyHasHarmonyChipAlert".Translate();
                this.explanationKey = "MLRP_AntiBronyHasHarmonyChipAlertText";
            }
        }

        public override AlertReport GetReport()
        {
            if (!royaltyActive)
                return false;

            return base.GetReport();
        }
    }

    // ANTI BRONIES DISLIKE BRONIES

    public class ThoughtWorker_AntiBronyVsBrony : ThoughtWorker
    {
        protected override ThoughtState CurrentSocialStateInternal(Pawn p, Pawn otherPawn)
        {
            if (!p.RaceProps.Humanlike)
            {
                return false;
            }
            if (!p.story.traits.HasTrait(DefDatabase<TraitDef>.GetNamed("MLRP_AntiBronyTrait")))
            {
                return false;
            }
            if (!otherPawn.RaceProps.Humanlike)
            {
                return false;
            }
            if (!otherPawn.story.traits.HasTrait(DefDatabase<TraitDef>.GetNamed("MLRP_BronyTrait")))
            {
                return false;
            }
            return true;
        }
    }

    public class Thought_AntiBronyVsBrony : Thought_SituationalSocial
    {
        public override float OpinionOffset()
        {
            if (ThoughtUtility.ThoughtNullified(pawn, def))
            {
                return 0f;
            }

            if (otherPawn.story.traits.HasTrait(DefDatabase<TraitDef>.GetNamed("MLRP_BronyTrait")))
            {
                return -10f;
            }
            return 0f;
        }
    }

    // BRONIES LIKE BRONIES

    public class ThoughtWorker_BronyLikesBrony : ThoughtWorker
    {
        protected override ThoughtState CurrentSocialStateInternal(Pawn p, Pawn otherPawn)
        {
            if (!p.RaceProps.Humanlike)
            {
                return false;
            }
            if (!p.story.traits.HasTrait(DefDatabase<TraitDef>.GetNamed("MLRP_BronyTrait")))
            {
                return false;
            }
            if (!otherPawn.RaceProps.Humanlike)
            {
                return false;
            }
            if (!otherPawn.story.traits.HasTrait(DefDatabase<TraitDef>.GetNamed("MLRP_BronyTrait")))
            {
                return false;
            }
            return true;
        }
    }
    public class Thought_BronyLikesBrony : Thought_SituationalSocial
    {
        public override float OpinionOffset()
        {
            if (ThoughtUtility.ThoughtNullified(pawn, def))
            {
                return 0f;
            }

            if (otherPawn.story.traits.HasTrait(DefDatabase<TraitDef>.GetNamed("MLRP_BronyTrait")))
            {
                return 10f;
            }
            return 0f;
        }
    }

    // HERBAL CURE KIT

    public class PoisonJokeAddictionCure : IngestionOutcomeDoer
    {
        protected override void DoIngestionOutcomeSpecial(Pawn pawn, Thing ingested, int ingestedCount)
        {
            List<Hediff> MLRP_HediffsToCheck = pawn.health.hediffSet.hediffs.ToList();
            foreach (Hediff hediff in MLRP_HediffsToCheck)
            {
                switch (hediff.def.defName)
                {
                    case "Flu":
                        pawn.health.RemoveHediff(hediff);
                        Messages.Message("MLRP_PawnCured".Translate(pawn, hediff.Label), MessageTypeDefOf.TaskCompletion, historical: false);
                        break;
                    case "Animal_Flu":
                        pawn.health.RemoveHediff(hediff);
                        Messages.Message("MLRP_PawnCured".Translate(pawn, hediff.Label), MessageTypeDefOf.TaskCompletion, historical: false);
                        break;
                    case "Malaria":
                        pawn.health.RemoveHediff(hediff);
                        Messages.Message("MLRP_PawnCured".Translate(pawn, hediff.Label), MessageTypeDefOf.TaskCompletion, historical: false);
                        break;
                    case "FoodPoisoning":
                        pawn.health.RemoveHediff(hediff);
                        Messages.Message("MLRP_PawnCured".Translate(pawn, hediff.Label), MessageTypeDefOf.TaskCompletion, historical: false);
                        break;
                    case "MLRP_PoisonJokeAddiction":
                        pawn.health.RemoveHediff(hediff);
                        Messages.Message("MLRP_PawnCured".Translate(pawn, hediff.Label), MessageTypeDefOf.TaskCompletion, historical: false);
                        break;
                    case "MLRP_PoisonJokeTolerance":
                        pawn.health.RemoveHediff(hediff);
                        Messages.Message("MLRP_PawnCured".Translate(pawn, hediff.Label), MessageTypeDefOf.TaskCompletion, historical: false);
                        break;
                    case "Plague":
                        System.Random PlagueCureChance = new System.Random();
                        int LuckyPlagueNumber = PlagueCureChance.Next(1, 11);
                        if (LuckyPlagueNumber == 7)
                        {
                            pawn.health.RemoveHediff(hediff);
                            Messages.Message("MLRP_PawnCured".Translate(pawn, hediff.Label), MessageTypeDefOf.TaskCompletion, historical: false);
                        }
                        if (LuckyPlagueNumber != 7)
                        {
                            Messages.Message("MLRP_CureFailed".Translate(pawn, hediff.Label), MessageTypeDefOf.TaskCompletion, historical: false);
                        }
                        break;
                    case "Animal_Plague":
                        System.Random AnimalPlagueCureChance = new System.Random();
                        int LuckyAnimalPlagueNumber = AnimalPlagueCureChance.Next(1, 11);
                        if (LuckyAnimalPlagueNumber == 7)
                        {
                            pawn.health.RemoveHediff(hediff);
                            Messages.Message("MLRP_PawnCured".Translate(pawn, hediff.Label), MessageTypeDefOf.TaskCompletion, historical: false);
                        }
                        if (LuckyAnimalPlagueNumber != 7)
                        {
                            Messages.Message("MLRP_CureFailed".Translate(pawn, hediff.Label), MessageTypeDefOf.TaskCompletion, historical: false);
                        }
                        break;
                    case "MagicalCakeAddiction": // RimPonk
                        pawn.health.RemoveHediff(hediff);
                        Messages.Message("MLRP_PawnCured".Translate(pawn, hediff.Label), MessageTypeDefOf.TaskCompletion, historical: false);
                        break;
                    case "MagicalCakeTolerance": // RimPonk
                        pawn.health.RemoveHediff(hediff);
                        Messages.Message("MLRP_PawnCured".Translate(pawn, hediff.Label), MessageTypeDefOf.TaskCompletion, historical: false);
                        break;
                    case "Diarrhea": // Dubs Bad Hygiene
                        pawn.health.RemoveHediff(hediff);
                        Messages.Message("MLRP_PawnCured".Translate(pawn, hediff.Label), MessageTypeDefOf.TaskCompletion, historical: false);
                        break;
                    default:
                        Log.Warning("MLRP_NothingToCure".Translate(pawn));
                        break;
                }
            }
        }
    }

    // POISON JOKE RANDOM EFFECT

    public class PoisonJokeSmoked : IngestionOutcomeDoer
    {
        protected override void DoIngestionOutcomeSpecial(Pawn pawn, Thing ingested, int ingestedCount)
        {
            System.Random r = new System.Random();
            int n = r.Next(1, 18); // maxValue must always be one greater than the number of available hediffs, otherwise the first hediff will always be chosen.
            var affliction = "";

            switch (n)
            {
                case 1:
                    pawn.health.AddHediff(DefDatabase<HediffDef>.GetNamed("MLRP_PoisonJokeIncreasedConsciousness"));
                    affliction = "MLRP_PoisonJokeGoodConsciousness".Translate(pawn);
                    break;
                case 2:
                    pawn.health.AddHediff(DefDatabase<HediffDef>.GetNamed("MLRP_PoisonJokeReducedConsciousness"));
                    affliction = "MLRP_PoisonJokeBadConsciousness".Translate(pawn);
                    break;
                case 3:
                    pawn.health.AddHediff(DefDatabase<HediffDef>.GetNamed("MLRP_PoisonJokeSuperSpeedy"));
                    affliction = "MLRP_PoisonJokeGoodSpeed".Translate(pawn);
                    break;
                case 4:
                    pawn.health.AddHediff(DefDatabase<HediffDef>.GetNamed("MLRP_PoisonJokeSlowAndSluggish"));
                    affliction = "MLRP_PoisonJokeBadSpeed".Translate(pawn);
                    break;
                case 5:
                    pawn.health.AddHediff(DefDatabase<HediffDef>.GetNamed("MLRP_PoisonJokeGoodManipulation"));
                    affliction = "MLRP_PoisonJokeGoodManipulation".Translate(pawn);
                    break;
                case 6:
                    pawn.health.AddHediff(DefDatabase<HediffDef>.GetNamed("MLRP_PoisonJokePoorManipulation"));
                    affliction = "MLRP_PoisonJokeBadManipulation".Translate(pawn);
                    break;
                case 7:
                    pawn.health.AddHediff(DefDatabase<HediffDef>.GetNamed("MLRP_PoisonJokeIncreasedTalking"));
                    affliction = "MLRP_PoisonJokeGoodTalking".Translate(pawn);
                    break;
                case 8:
                    pawn.health.AddHediff(DefDatabase<HediffDef>.GetNamed("MLRP_PoisonJokeReducedTalking"));
                    affliction = "MLRP_PoisonJokeBadTalking".Translate(pawn);
                    break;
                case 9:
                    pawn.health.AddHediff(DefDatabase<HediffDef>.GetNamed("MLRP_PoisonJokeIncreasedEating"));
                    affliction = "MLRP_PoisonJokeGoodEating".Translate(pawn);
                    break;
                case 10:
                    pawn.health.AddHediff(DefDatabase<HediffDef>.GetNamed("MLRP_PoisonJokeReducedEating"));
                    affliction = "MLRP_PoisonJokeBadEating".Translate(pawn);
                    break;
                case 11:
                    pawn.health.AddHediff(DefDatabase<HediffDef>.GetNamed("MLRP_PoisonJokeSightBeyondSight"));
                    affliction = "MLRP_PoisonJokeGoodSight".Translate(pawn);
                    break;
                case 12:
                    pawn.health.AddHediff(DefDatabase<HediffDef>.GetNamed("MLRP_PoisonJokeBlindness"));
                    affliction = "MLRP_PoisonJokeBadSight".Translate(pawn);
                    break;
                case 13:
                    pawn.health.AddHediff(DefDatabase<HediffDef>.GetNamed("MLRP_PoisonJokeIncreasedHearing"));
                    affliction = "MLRP_PoisonJokeGoodHearing".Translate(pawn);
                    break;
                case 14:
                    pawn.health.AddHediff(DefDatabase<HediffDef>.GetNamed("MLRP_PoisonJokeReducedHearing"));
                    affliction = "MLRP_PoisonJokeBadHearing".Translate(pawn);
                    break;
                case 15:
                    pawn.health.AddHediff(DefDatabase<HediffDef>.GetNamed("MLRP_PoisonJokeIncreasedBreathing"));
                    affliction = "MLRP_PoisonJokeGoodBreathing".Translate(pawn);
                    break;
                case 16:
                    pawn.health.AddHediff(DefDatabase<HediffDef>.GetNamed("MLRP_PoisonJokeReducedBreathing"));
                    affliction = "MLRP_PoisonJokeBadBreathing".Translate(pawn);
                    break;
                case 17:
                    pawn.health.AddHediff(DefDatabase<HediffDef>.GetNamed("MLRP_CutiePox"));
                    affliction = "MLRP_PoisonJokeCutiePox".Translate(pawn);
                    break;
            }
            if (n == 2 || n == 4 || n == 6 || n == 8 || n == 10 || n == 12 || n == 14 || n == 16 || n == 17)
            {
                LetterDef MLRP_PoisonJokeAfflictionLetter = LetterDefOf.ThreatSmall;
                string title = "MLRP_PoisonJokeLetterTitle".Translate();
                string text = affliction;
                Find.LetterStack.ReceiveLetter(title, text, MLRP_PoisonJokeAfflictionLetter);
            }
            else
            {
                LetterDef MLRP_PoisonJokeAfflictionLetter = LetterDefOf.NeutralEvent;
                string title = "MLRP_PoisonJokeLetterTitle".Translate();
                string text = affliction;
                Find.LetterStack.ReceiveLetter(title, text, MLRP_PoisonJokeAfflictionLetter);
            }
        }
    }

    // PORTAL ROOM

    public class RoomRoleWorker_PortalRoom : RoomRoleWorker
    {
        public override float GetScore(Room room)
        {
            int num = 0;
            List<Thing> andAdjacentThings = room.ContainedAndAdjacentThings;
            for (int index = 0; index < andAdjacentThings.Count; ++index)
            {
                if (andAdjacentThings[index].def == DefDatabase<ThingDef>.GetNamed("MLRP_MagicMirrorGenerator"))
                    ++num;
            }
            return 10f * (float)num;
        }
    }

    // PARTY CANNON

    public class MLRP_PartyCannonMoodBoost : CompTargetEffect
    {
        public override void DoEffectOn(Pawn user, Thing target)
        {
            Pawn pawn = (Pawn)target;
            if (pawn.Dead || pawn.needs == null || pawn.needs.mood == null)
                return;
            if (pawn.IsColonist) // Pawn is a colonist
            {
                if (!pawn.story.traits.HasTrait(DefDatabase<TraitDef>.GetNamed("MLRP_BronyTrait")) && !pawn.story.traits.HasTrait(DefDatabase<TraitDef>.GetNamed("MLRP_AntiBronyTrait"))) // Colonist has neither the brony or anti brony trait
                {
                    pawn.needs.mood.thoughts.memories.TryGainMemory((Thought_Memory)ThoughtMaker.MakeThought(DefDatabase<ThoughtDef>.GetNamed("MLRP_PartyCannonBoostRegularPawn")));
                }
                if (pawn.story.traits.HasTrait(DefDatabase<TraitDef>.GetNamed("MLRP_BronyTrait")) && !pawn.story.traits.HasTrait(DefDatabase<TraitDef>.GetNamed("MLRP_AntiBronyTrait"))) // Colonist has the brony trait
                {
                    pawn.needs.mood.thoughts.memories.TryGainMemory((Thought_Memory)ThoughtMaker.MakeThought(DefDatabase<ThoughtDef>.GetNamed("MLRP_PartyCannonBoostBrony")));
                }
                if (!pawn.story.traits.HasTrait(DefDatabase<TraitDef>.GetNamed("MLRP_BronyTrait")) && pawn.story.traits.HasTrait(DefDatabase<TraitDef>.GetNamed("MLRP_AntiBronyTrait"))) // Colonist has the anti brony trait
                {
                    pawn.needs.mood.thoughts.memories.TryGainMemory((Thought_Memory)ThoughtMaker.MakeThought(DefDatabase<ThoughtDef>.GetNamed("MLRP_PartyCannonBoostAntiBrony")));
                }
            }
            if (pawn.IsPrisoner) // Pawn is a prisoner
            {
                pawn.needs.mood.thoughts.memories.TryGainMemory((Thought_Memory)ThoughtMaker.MakeThought(DefDatabase<ThoughtDef>.GetNamed("MLRP_PartyCannonBoostPrisoner")));
            }
            if (ModsConfig.IsActive("Ludeon.RimWorld.Ideology") && pawn.IsSlave) // Pawn is a slave (requires Ideology DLC)
            {
                pawn.needs.mood.thoughts.memories.TryGainMemory((Thought_Memory)ThoughtMaker.MakeThought(DefDatabase<ThoughtDef>.GetNamed("MLRP_PartyCannonBoostSlave")));
            }
        }
    }

    // SCREWBALL ROOM

    public class RoomRoleWorker_ScrewballRoom : RoomRoleWorker
    {
        public override float GetScore(Room room)
        {
            int num = 0;
            List<Thing> andAdjacentThings = room.ContainedAndAdjacentThings;
            for (int index = 0; index < andAdjacentThings.Count; ++index)
            {
                if (andAdjacentThings[index].def == DefDatabase<ThingDef>.GetNamed("MLRP_ScrewballGenerator"))
                    ++num;
            }
            return 10f * (float)num;
        }
    }

    // PLUSHIE RECYCLING
	
	public class RecyclePlushieExtension : DefModExtension
	{
		public int reclaimedAmount = 75; // Default value if not specified
	}

    public class Recipe_RecyclePlushie : RecipeWorker
    {
        public override void ConsumeIngredient(Thing ingredient, RecipeDef recipe, Map map)
        {
            base.ConsumeIngredient(ingredient, recipe, map);
            ThingDef stuff = ingredient.Stuff;

            if (stuff != null)
            {
                // Try to get the mod extension that contains the 'reclaimedAmount' value
                var extension = recipe.GetModExtension<RecyclePlushieExtension>();

                // Use the value from the extension, default to 75 if not found
                int amount = extension?.reclaimedAmount ?? 75;

                Thing reclaimedMaterial = ThingMaker.MakeThing(stuff);
                reclaimedMaterial.stackCount = amount;
                GenPlace.TryPlaceThing(reclaimedMaterial, ingredient.Position, map, ThingPlaceMode.Near);
            }
        }
    }

    // CUTIE POX CURE

    public class CutiePoxCure : IngestionOutcomeDoer
    {
        protected override void DoIngestionOutcomeSpecial(Pawn pawn, Thing ingested, int ingestedCount)
        {
            List<Hediff> MLRP_HediffsToCheck = pawn.health.hediffSet.hediffs.ToList();
            foreach (Hediff hediff in MLRP_HediffsToCheck)
            {
                switch (hediff.def.defName)
                {
                    case "MLRP_CutiePox":
                        pawn.health.RemoveHediff(hediff);
                        Messages.Message("MLRP_PawnCured".Translate(pawn, hediff.Label), MessageTypeDefOf.TaskCompletion, historical: false);
                        break;
                    default:
                        Log.Warning("MLRP_NothingToCure".Translate(pawn));
                        break;
                }
            }
        }
    }
}